import React from "react";

function Header() {
  return (
    <div className="container ">
      <header className="heading">FOOD RECIPE FINDER</header>
    </div>
  );
}

export default Header;
