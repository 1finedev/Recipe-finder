import React from "react";
import style from "./recipe.module.css";

function Recipe({ title, image, ingredients }) {
  return (
    <div className={style.recipe}>
      <div>
        <h3 className={style.title}>{title}</h3>
        <img className={style.image} src={image} alt="" />
      </div>
      <div className={style.ingrid}>
        <ul>
          <em>
            {ingredients.map((ingredient, index) => (
              <li key={index}>{ingredient.text}</li>
            ))}
          </em>
        </ul>
      </div>
      <hr />
    </div>
  );
}

export default Recipe;
