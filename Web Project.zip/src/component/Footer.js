import React from "react";

function Footer() {
  return (
    <div>
      <nav className="navbar container2 navbar-light bg-light">
        <footer className="page-footer font-small black">
          <div className="footer-copyright footer text-center py-3">
            © 2019 Copyright: Built at 'Klin-Coders' by
            <a href="mailto:emmanuel.bayode.0388@gmail.com"> Emmanuel</a>
          </div>
        </footer>
      </nav>
    </div>
  );
}

export default Footer;
