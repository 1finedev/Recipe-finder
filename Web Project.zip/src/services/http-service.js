import 'whatwg-fetch';

class HttpService {
  getProducts = () => {
    
  }
}
