import React, { useState, useEffect } from "react";
import "./App.css";
import Recipe from "./component/Recipe";
import Header from "./component/Header";
import Footer from "./component/Footer";

const App = () => {
  const appID = "70a6e04d";
  const appKey = "5c83783e8262742ff2f7e6fb7a61b11f";

  const [recipes, setrecipes] = useState([]);
  const [search, setsearch] = useState("");
  const [query, setquery] = useState("omelette");
  const [isLoading, setisLoading] = useState(true);
  const [emptyRes, setemptyRes] = useState(false);
  const [resNo, setresNo] = useState(10);

  useEffect(() => {
    const getRecipes = async () => {
      const response = await fetch(
        `https://api.edamam.com/search?q=${query}&app_id=${appID}&app_key=${appKey}&from=0&to=${resNo}`
      );
      const data = await response.json();
      !data.more ? errorload() : setemptyRes(false);
      setrecipes(data.hits);
      console.log(data);
      setisLoading(false);
    };
    getRecipes();
  }, [query, resNo]);

  const errorload = () => {
    setemptyRes(true);
    document
      .getElementsByTagName("input")[0]
      .setAttribute("class", "errorclass");
  };
  const searchChange = e => {
    setsearch(e.target.value);
  };

  const handleChange = e => {
    e.preventDefault();
    setquery(search);
    setisLoading(!isLoading);
    setsearch("");
  };

  return (
    <div>
      <div>
        <Header />
      </div>
      <div className="container container1">
        <hr />
        <form onSubmit={handleChange}>
          <input
            type="text"
            placeholder="Enter Recipe Keywords..."
            value={search}
            onChange={searchChange}
          />
          <button type="submit">Find Recipes</button>
        </form>
        <hr />
        <div className="recipes">
          {emptyRes ? (
            <div>
              <h5 className="loading">
                Oops! no match found for{" "}
                <span className="errorquery">"{query}"</span>, kindly try a new
                recipe search...
              </h5>
            </div>
          ) : !isLoading ? (
            <div>
              <div className="recipes">
                {recipes.map(recipe => (
                  <Recipe
                    key={recipe.recipe.image}
                    title={recipe.recipe.label}
                    image={recipe.recipe.image}
                    ingredients={recipe.recipe.ingredients}
                  />
                ))}{" "}
              </div>
              <div>
                <button
                  className="loadmore"
                  onClick={() => {
                    setresNo(resNo + 10);
                  }}
                >
                  Click here to load more results
                </button>
                <hr />{" "}
              </div>
            </div>
          ) : (
            <div>
              <div className="wrap">
                <div className="spinner spinner-1"></div>
                <div className="spinner spinner-2"></div>
                <div className="spinner spinner-3"></div>
                <div className="spinner spinner-4"></div>
                <span></span>
                <span></span>
                <span></span>
                <h5 className="loading">PLEASE WAIT: "LOADING..."</h5>
              </div>
            </div>
          )}
        </div>
      </div>
      <br />
      <Footer />
    </div>
  );
};
export default App;
